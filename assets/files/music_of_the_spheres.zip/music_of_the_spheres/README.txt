Compile with XCode on Mac OSX, Visual Studio on Windows and QTCreator on Linux. You will need openFrameworks installed.
